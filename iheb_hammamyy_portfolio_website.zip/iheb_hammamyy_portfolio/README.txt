IHEB_HAMMAMYY_PORTFOLIO — WEBSITE FILES

Preview locally:
1. Extract this folder.
2. Open index.html in a web browser.

Publish free with GitHub Pages:
1. Create/sign in to GitHub.
2. Create a public repository named iheb-hammamyy-portfolio.
3. Upload index.html and the assets folder (keep their structure).
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. After deployment, GitHub will show your public website URL.

The website name is IHEB_HAMMAMYY_PORTFOLIO. The free hosting URL will be based on your GitHub username/repository; the exact URL depends on your GitHub username.
